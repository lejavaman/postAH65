tcov@PO220004931:~/Models/Festschrift_Anne$ ocra21 -int
*** This is ocra 2.1.0 (compiled on Fri Jul  2 09:11:08 2021)
*** For more information on ocra see <https://ocra.fbk.eu>
*** For bug reports, or any comment, please send an email to <ocra@fbk.eu>.
*** Copyright (c) 2013, Fondazione Bruno Kessler

*** This version of ocra is linked to NuSMV 2.6.0.
*** For more information on NuSMV see <http://nusmv.fbk.eu>
*** or email to <nusmv-users@fbk.eu>.
*** Copyright (C) 2010-2021, Fondazione Bruno Kessler

*** This version of ocra is linked to the CUDD library version 2.4.1
*** Copyright (c) 1995-2004, Regents of the University of Colorado

*** This version of ocra is linked to the MiniSat SAT solver.
*** See http://minisat.se/MiniSat.html
*** Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
*** Copyright (c) 2007-2010, Niklas Sorensson

ocra > ocra_check_syntax -i flank_1.oss
warning: waiting an oss constraint from standard input
Success: the oss specification is syntactically correct
ocra > ocra_check_re
ocra_check_receptiveness  ocra_check_refinement
ocra > ocra_check_refinement

Checking refinement of component: Tournai
  Checking "CONTRACT Flank_32H-33H REFINEDBY VIXL16.Flank_32H-33H, VIXL15.Flank_32H-33H;"
    Checking the correct implementation of "Flank_32H-33H"... [OK]
    Checking the correct environment of "VIXL16.Flank_32H-33H"... [OK]
    Checking the correct environment of "VIXL15.Flank_32H-33H"... [OK]

Checking refinement of component: M16

Checking refinement of component: M15

  Summary: everything is OK.
ocra >